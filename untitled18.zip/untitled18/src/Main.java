import java.util.Random;

public class Main {
    public static int bossHealth=700;
    public static int bossDamage=50;
    public static String[] bossDefenceType={};
    public static int[] heroesHealth={270,280,260};
    public static int[] heroesDamage={20,15,25};
    public static String[] heroesAttackType={"Physical","Kinetic","Magical"};
    public static int roundNum=0;

    public static void main(String[] args) {
        printstatics();
        round();

    }
    public static void printstatics(){
        System.out.println("******* Round "+roundNum+" *******");
        System.out.println("BossHealth: "+bossHealth+"["+bossDamage+"]");
        for(int i=0;i<heroesHealth.length;++i){
            System.out.println(heroesAttackType[i]+" health; "+heroesHealth[i]+"["+heroesDamage[i]+"]");
        }
    }
    public static void bossHits(){
        for(int i=0;i<heroesHealth.length;++i){
            if(heroesHealth[i]<bossDamage){
                heroesHealth[i]=0;
            }
            heroesHealth[i]-=bossDamage;

        }
    }
    public static void heroesHits(){
        for(int i=0;i<heroesHealth.length;++i){
            bossHealth-=heroesDamage[i];
            if(heroesHealth[i]>0 && bossHealth>0){
                bossHealth-=heroesDamage[i];
            }

        }
    }
    public static void round(){
        roundNum++;
        bossHits();
        heroesHits();
        printstatics();
    }
    public static Boolean isGameFinished(){
        if(bossHealth<=0){
            bossHealth=0;
            System.out.println("Heroes won!");
            return true;
        }
        if(heroesHealth[0]<=0 && heroesHealth[1]<=0 && heroesHealth[2]<=0){
            System.out.println("Defeat");
            return true;
        }
        return false;
    }
    public static void chooseBossDefence(){
        Random raandom=new Random();
        bossDefenceType=heroesAttackType(3);

    }
}